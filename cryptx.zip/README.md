# CryptX

CryptX provides cryptography for the TI-84+ CE graphing calculator.

## Getting Started with CryptX

Visit the [CryptX Documentation](https://acagliano.github.io/cryptx) for help with using 
the library, documentation, cryptanalysis, credits, and more.
